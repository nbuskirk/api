APICA Demo API
======================

This is a demo angular application, consuming a node.js/express REST API backend. This is experimental and currently in development stages.
